from django.urls import path
from . import views
app_name = "todo_maker"

urlpatterns = [
    path('', views.List.as_view(),name="list-todo"),
    path('save', views.List.as_view(),name="save-todo"),
    path('edit/', views.List.as_view(),name="edit-todo"),
    path('remove/', views.List.as_view(),name="remove-todo"),
    path('task-completed', views.List.as_view(),name="todo-task-completed"),
]