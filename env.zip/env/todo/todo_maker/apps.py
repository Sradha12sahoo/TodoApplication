from django.apps import AppConfig


class TodoMakerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'todo_maker'
